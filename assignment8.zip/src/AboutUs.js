import React from "react";

class AboutUs extends React.Component{
    render(){
        return(
            <div>
                <h1>About Us</h1>
                <p></p>
            </div>
        )
    }
}

export default AboutUs;