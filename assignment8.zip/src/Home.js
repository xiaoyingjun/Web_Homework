import React from "react";

class Home extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            buttonText: 'Red'
        }
        //this.toContact = this.toContact.bind(this);
    }
   
    toContact = () => {
        this.props.history.push("/contactUs");
    }

    render(){
        return(
            <div>
                <h2>Home Page</h2>
                <p> HomePage Content</p>
                <button onClick={this.toContact}>ContactUs</button>
                <button onClick={this.toAbout}>{this.state.buttonText}</button>
            </div>
        )
    }
}
export default Home; 