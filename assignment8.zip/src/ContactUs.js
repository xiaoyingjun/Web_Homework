import React from "react";

class ContactUs extends React.Component{
    render(){
        return(
            <div>
                <h1>Contact Us</h1>
                <p></p>
            </div>
        )
    }
}

export default ContactUs;