import logo from './logo.svg';
import './App.css';
import React from 'react';
import {Route,NavLink,HashRouter,Switch} from 'react-router-dom';
import Home from './Home';
import AboutUs from './AboutUs';
import ContactUs from './ContactUs';


class App extends React.Component{
  render() {
    return(
      <HashRouter>
        <div>
          <div>
            <h1>assignment8</h1>
            <ul className = 'header'>
              <li><NavLink to = "/">Home</NavLink></li>
              <li><NavLink to = "/aboutUs">About US</NavLink></li>
              <li><NavLink to = "/">Home</NavLink></li>
              <li><NavLink to = "/">Home</NavLink></li>
            </ul>
          </div>
          <div className = 'content'>
            <Switch>
              <Route exact path = '/Home' component = {Home}></Route>
              <Route exact path = '/AboutUs' component = {AboutUs}></Route>
              <Route exact path = '/ContactUs' component = {ContactUs}></Route>
            </Switch>
          </div>
        </div>
      </HashRouter>
    )
  }
}

function bpp() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
