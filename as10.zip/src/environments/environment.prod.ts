export const environment = {
  production: true,
  baseUrl: '/demo/angular-inventory/dist'
};
